package com.grabRental.cs544.enumeration;

public enum Location {
	FAIR_FIELD, OTTA_MUA, IOWA_CITY;
}	
