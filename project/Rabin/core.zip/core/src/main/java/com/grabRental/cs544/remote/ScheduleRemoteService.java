package com.grabRental.cs544.remote;

public interface ScheduleRemoteService{
	
}
