package com.grabRental.cs544.enumeration;

public enum VehicleType {
    SEDAN, HATCHBACK, SUV
}
