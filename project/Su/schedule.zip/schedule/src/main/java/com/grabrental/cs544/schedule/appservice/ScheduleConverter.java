package com.grabrental.cs544.schedule.appservice;

import com.grabRental.cs544.dto.ScheduleDTO;
import com.grabRental.cs544.model.Schedule;

public class ScheduleConverter {

	public Schedule toDAO(ScheduleDTO scheduleDTO) {
		Schedule schedule = new Schedule();
		return schedule;
	}
	
	
	public ScheduleDTO toDTO(Schedule schedule) {
		ScheduleDTO scheduleDTO = new ScheduleDTO();
		return scheduleDTO;
	}
}
